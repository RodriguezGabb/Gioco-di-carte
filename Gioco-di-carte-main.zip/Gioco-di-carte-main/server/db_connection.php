<?php
$db = pg_connect("host=localhost port=5433 dbname=LTW user=postgres password=serverGod162");//andrea
//$db = pg_connect("host=localhost port=5432 dbname=ltw user=postgres password=biar");//gabriel
?>